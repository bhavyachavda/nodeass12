import logo from './logo.svg';
import './App.css';
import React, { useState, useEffect } from 'react';
import Assignment1 from './Assignment1';
import Assignment2 from './Assignment2';

function App() {
  // const [message, setMessage] = useState("");

  // useEffect(() => {
  //   fetch("http://localhost:8000/message")
  //     .then((res) => res.json())
  //     .then((data) => setMessage(data.message));
  // }, []);

  return (
    <div className='App'>
      {/* <h1>{message}</h1> */}
      {/* <h3>Prime</h3> */}
      <Assignment1 />
      <Assignment2/>
    </div>
  );
}

export default App;

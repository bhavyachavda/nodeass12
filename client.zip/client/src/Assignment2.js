import React, { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";

function Assignment2() {
    const [message1, setMessage1] = useState("");
    const [message2, setMessage2] = useState("");
    const [ans, setAns] = useState([]);

    useEffect(() => {

    }, [message1, message2]);

    function handleSubmit(event) {
        event.preventDefault();

        axios.get("http://localhost:6006/", { params: { message1, message2 } }).then((res) => {
            console.log(res.data)

            setAns(res.data.ans)
        }).catch((error) => { console.log(error) })
    }
    return (
        <div>
            <form onSubmit={handleSubmit}>
                <div>
                    <label> Enter number
                        <input type='text' name="message" value={message1} id="message1" onChange={(event) => { setMessage1(event.target.value) }} />
                    </label>
                </div>
                <br />
                <div>
                    <label> Enter power of number
                        <input type='text' name="message" value={message2} id="message2" onChange={(event) => { setMessage2(event.target.value) }} />
                    </label>
                </div>
                <br />
                <div>
                    <input type="submit" value="submit" />
                </div>
            </form>
            {ans != 0 ? <div><p>{ans}</p></div> : <></>}
            {/* <h1>{message}</h1> */}
        </div>
    );
}
export default Assignment2;